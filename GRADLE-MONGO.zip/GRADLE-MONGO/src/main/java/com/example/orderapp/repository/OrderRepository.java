package com.example.orderapp.repository;

import com.example.orderapp.model.Order;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;

public interface OrderRepository extends ReactiveMongoRepository<Order, ObjectId> {
    Mono<Order> findByOrderId(String orderId);
    Flux<Order> findByTsBetween(OffsetDateTime from, OffsetDateTime to);
}
