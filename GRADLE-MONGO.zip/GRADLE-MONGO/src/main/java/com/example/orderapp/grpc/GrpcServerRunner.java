package com.example.orderapp.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class GrpcServerRunner {

    private final OrderServiceGrpc.OrderServiceImplBase orderService;
    private Server server;
    private final Logger log = LoggerFactory.getLogger(GrpcServerRunner.class);

    @Value("${grpc.server.port:6565}")
    private int grpcPort;

    public GrpcServerRunner(GrpcOrderService orderService) {
        this.orderService = orderService;
    }

    @PostConstruct
    public void start() throws Exception {
        server = ServerBuilder.forPort(grpcPort)
                .addService(orderService)
                .build()
                .start();
        log.info("gRPC server started on port {}", grpcPort);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                GrpcServerRunner.this.stop();
            } catch (Exception e) {
                // ignore
            }
        }));
    }

    @PreDestroy
    public void stop() throws Exception {
        if (server != null) {
            server.shutdown();
        }
    }
}
