package com.example.orderapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.netty.NettyReactiveWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.stereotype.Component;

@Component
public class WebfluxPortCustomizer implements WebServerFactoryCustomizer<NettyReactiveWebServerFactory> {

    @Value("${app.apiPort}")
    private int apiPort;

    @Override
    public void customize(NettyReactiveWebServerFactory factory) {
        factory.setPort(apiPort);
    }
}
