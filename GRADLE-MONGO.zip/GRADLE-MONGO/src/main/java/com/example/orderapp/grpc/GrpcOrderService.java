package com.example.orderapp.grpc;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import com.example.orderapp.actor.OrderProcessorActor;
import com.example.orderapp.model.Order;
import com.example.orderapp.repository.OrderRepository;
import com.example.orderapp.service.MetricsService;
import io.grpc.stub.StreamObserver;
import order.OrderRequest;
import order.OrderResponse;
import order.OrderServiceGrpc;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class GrpcOrderService extends OrderServiceGrpc.OrderServiceImplBase {

    private final ActorSystem actorSystem;
    private final ActorRef orderProcessor;
    private final OrderRepository repository;
    private final MetricsService metricsService;
    private final Logger log = LoggerFactory.getLogger(GrpcOrderService.class);

    public GrpcOrderService(ActorSystem actorSystem, OrderRepository repository, MetricsService metricsService, com.example.orderapp.smpp.SmppClientService smppClientService) {
        this.actorSystem = actorSystem;
        this.repository = repository;
        this.metricsService = metricsService;
        this.orderProcessor = actorSystem.actorOf(OrderProcessorActor.props(repository, smppClientService), "orderProcessor");
    }

    @Override
    public void insertOrder(OrderRequest request, StreamObserver<OrderResponse> responseObserver) {
        log.info("gRPC: InsertOrder pedidoId={}", request.getOrderId());

        Order order = new Order();
        order.set_id(new ObjectId());
        order.setOrderId(request.getOrderId());
        order.setCustomerId(request.getCustomerId());
        order.setCustomerPhoneNumber(request.getCustomerPhoneNumber());
        order.setItems(request.getItemsList());

        CompletableFuture<String> replyFuture = new CompletableFuture<>();

        orderProcessor.tell(new OrderProcessorActor.ProcessOrder(order, replyFuture), ActorRef.noSender());

        replyFuture.whenComplete((status, ex) -> {
            if (ex != null) {
                responseObserver.onError(ex);
            } else {
                metricsService.incrementProcessedOrders();
                OrderResponse resp = OrderResponse.newBuilder()
                        .setOrderId(order.getOrderId())
                        .setStatus(status)
                        .build();
                responseObserver.onNext(resp);
                responseObserver.onCompleted();
            }
        });
    }
}
