package com.example.orderapp.actors;

import akka.actor.AbstractActor;
import com.example.orderapp.model.Order;
import com.example.orderapp.repository.OrderRepository;
import com.example.orderapp.smpp.SmppClientService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

public class OrderProcessorActor extends AbstractActor {

    private final Logger log = LoggerFactory.getLogger(OrderProcessorActor.class);

    private final OrderRepository repository;
    private final SmppClientService smppClientService;

    public OrderProcessorActor(OrderRepository repository, SmppClientService smppClientService) {
        this.repository = repository;
        this.smppClientService = smppClientService;
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(ProcessOrder.class, this::onProcessOrder)
                .build();
    }

    private void onProcessOrder(ProcessOrder msg) {
        try {
            repository.save(msg.order).block();
            msg.order.setStatus("PROCESSED");
            repository.save(msg.order).block();

            // 📲 Construir mensaje SMS
            String smsText = "Your order " + msg.order.getOrderId() + " has been processed";

            // 🔹 Enviar SMS de manera asíncrona
            smppClientService.sendSms(msg.order.getCustomerPhoneNumber(), smsText)
                    .whenComplete((messageId, ex) -> {
                        if (ex != null) {
                            log.error(" Error enviando SMS para pedido {}: {}", msg.order.getOrderId(), ex.getMessage());
                        } else {
                            log.info("✅ SMS enviado para pedido {} con messageId={}", msg.order.getOrderId(), messageId);
                        }
                    });

            // Responder inmediatamente que el pedido fue procesado
            msg.replyFuture.complete("PROCESSED");
        } catch (Exception ex) {
            log.error("Error procesando pedido {}: {}", msg.order.getOrderId(), ex.getMessage());
            msg.replyFuture.completeExceptionally(ex);
        }
    }

    // Mensaje usado por el actor
    public static class ProcessOrder {
        public final Order order;
        public final CompletableFuture<String> replyFuture;

        public ProcessOrder(Order order, CompletableFuture<String> replyFuture) {
            this.order = order;
            this.replyFuture = replyFuture;
        }
    }
}
