package com.example.orderapp.smpp;

import com.cloudhopper.smpp.SmppSession;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.cloudhopper.smpp.SmppBindType;
import com.cloudhopper.smpp.pdu.SubmitSm;
import com.cloudhopper.smpp.pdu.SubmitSmResp;
import com.cloudhopper.smpp.impl.DefaultSmppClient;
import com.cloudhopper.smpp.type.Address;
import com.cloudhopper.smpp.util.AddressUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

@Service
public class SmppClientService {

    private final Logger log = LoggerFactory.getLogger(SmppClientService.class);

    @Value("${app.smpp.host}")
    private String host;
    @Value("${app.smpp.port}")
    private int port;
    @Value("${app.smpp.systemId}")
    private String systemId;
    @Value("${app.smpp.password}")
    private String password;
    @Value("${app.smpp.sourceAddress:SENDER}")
    private String sourceAddress;
    @Value("${app.smpp.enquireLinkTimer:10000}")
    private long enquireLinkTimer;
    @Value("${app.smpp.connectRetries:3}")
    private int connectRetries;
    @Value("${app.smpp.submitTimeoutMs:10000}")
    private long submitTimeoutMs;

    private DefaultSmppClient client;
    private volatile SmppSession session;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private final ExecutorService sendExecutor = Executors.newFixedThreadPool(4);

    @PostConstruct
    public void init() throws Exception {
        client = new DefaultSmppClient();
        bindSessionWithRetries();
        // Opcional: schedule health checks (enquire link)
        scheduler.scheduleAtFixedRate(this::ensureBound, enquireLinkTimer, enquireLinkTimer, TimeUnit.MILLISECONDS);
    }

    private void bindSessionWithRetries() {
        int attempts = 0;
        Exception lastEx = null;
        while (attempts < connectRetries) {
            try {
                SmppSessionConfiguration config = new SmppSessionConfiguration();
                config.setWindowSize(1);
                config.setName("smpp-session");
                config.setType(SmppBindType.TRANSCEIVER);
                config.setHost(host);
                config.setPort(port);
                config.setSystemId(systemId);
                config.setPassword(password);
                // Puedes ajustar otros parámetros: systemType, bindTimeout, enquireLinkTimer, etc.

                log.info("SMPP: intentando bind a {}:{} (intento {}/{})", host, port, attempts + 1, connectRetries);
                this.session = client.bind(config);
                log.info("SMPP: sesión bind exitosa a {}:{}", host, port);
                return;
            } catch (Exception ex) {
                lastEx = ex;
                attempts++;
                log.warn("SMPP: fallo bind (intento {}/{}): {}", attempts, connectRetries, ex.getMessage());
                try {
                    Thread.sleep(2000L);
                } catch (InterruptedException ignored) { }
            }
        }
        log.error("SMPP: no se pudo bindear después de {} intentos", connectRetries, lastEx);
    }

    private synchronized void ensureBound() {
        try {
            if (session == null || !session.isBound()) {
                log.warn("SMPP: sesión no vinculada. Intentando rebind...");
                bindSessionWithRetries();
            }
        } catch (Exception e) {
            log.error("SMPP: error en ensureBound: {}", e.getMessage());
        }
    }

    /**
     * Envía un SMS y devuelve un CompletableFuture que resuelve con messageId del submit.
     */
    public CompletableFuture<String> sendSmsWithRetry(String destinationPhone, String text) {
        return CompletableFuture.supplyAsync(() -> {
            int maxRetries = 3;
            long backoff = 1000; // 1s inicial
            Exception lastEx = null;

            for (int attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    if (session == null || !session.isBound()) {
                        log.warn("SMPP: sesión no vinculada. Intentando rebind...");
                        bindSessionWithRetries();
                    }

                    SubmitSm submit = new SubmitSm();
                    submit.setDestAddress(destinationPhone);
                    submit.setShortMessage(text.getBytes(StandardCharsets.UTF_8));

                    SubmitSmResp resp = session.submit(submit, submitTimeoutMs);
                    String messageId = resp == null ? null : resp.getMessageId();

                    log.info("SMPP: SMS enviado a {} messageId={} (intento {}/{})",
                            destinationPhone, messageId, attempt, maxRetries);
                    return messageId;
                } catch (Exception ex) {
                    lastEx = ex;
                    log.warn("SMPP: fallo intento {}/{} para {}: {}",
                            attempt, maxRetries, destinationPhone, ex.getMessage());
                    try {
                        Thread.sleep(backoff);
                    } catch (InterruptedException ignored) {}
                    backoff *= 2; // backoff exponencial
                }
            }
            throw new RuntimeException("SMPP: no se pudo enviar SMS a " + destinationPhone, lastEx);
        }, sendExecutor);
    }









    @PreDestroy
    public void shutdown() {
        try {
            if (session != null) {
                try { session.unbind(5000); } catch (Exception ignored) {}
                try { session.destroy(); } catch (Exception ignored) {}
            }
            if (client != null) {
                client.destroy();
            }
        } finally {
            scheduler.shutdownNow();
            sendExecutor.shutdownNow();
        }
        log.info("SMPP: cerrado");
    }
}
