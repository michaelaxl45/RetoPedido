package com.example.orderapp.service;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Service;

@Service
public class MetricsService {

    private final Counter processedOrdersCounter;

    public MetricsService(MeterRegistry registry) {
        this.processedOrdersCounter = Counter.builder("orders.processed.count")
                .description("Número de pedidos procesados por el sistema")
                .register(registry);
    }

    public void incrementProcessedOrders() {
        processedOrdersCounter.increment();
    }
}
