package com.example.orderapp.util;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

public class Converters {

    @WritingConverter
    public static class OffsetDateTimeToInstantConverter implements Converter<OffsetDateTime, Instant> {
        @Override
        public Instant convert(OffsetDateTime source) {
            return source == null ? null : source.toInstant();
        }
    }

    @ReadingConverter
    public static class InstantToOffsetDateTimeConverter implements Converter<Instant, OffsetDateTime> {
        @Override
        public OffsetDateTime convert(Instant source) {
            return source == null ? null : OffsetDateTime.ofInstant(source, ZoneOffset.UTC);
        }
    }

    public static List<Object> getConverters() {
        List<Object> conv = new ArrayList<>();
        conv.add(new OffsetDateTimeToInstantConverter());
        conv.add(new InstantToOffsetDateTimeConverter());
        return conv;
    }
}
