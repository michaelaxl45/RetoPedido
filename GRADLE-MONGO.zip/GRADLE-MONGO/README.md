# Spring WebFlux + gRPC + Akka + SMPP (Example Project)

## Requisitos
- Java 17
- Gradle
- MongoDB disponible en mongodb://127.0.0.1:27017 (o cambia application.yml)

## Build
./gradlew build

## Ejecutar
./gradlew bootRun

El servidor WebFlux arrancará en el puerto que pongas en `app.apiPort` (por defecto 9898).

## gRPC
- Proto: src/main/proto/order.proto. El plugin protobuf genera código gRPC en build/generated.

## Endpoints REST
- GET /orders/{orderId}/status  -> devuelve el estado del pedido
- GET /orders/count?from=<ISO_DATETIME>&to=<ISO_DATETIME> -> total de pedidos en rango

## Actuator Prometheus
- GET /actuator/prometheus
